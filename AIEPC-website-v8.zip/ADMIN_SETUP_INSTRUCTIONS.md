# Admin Setup Instructions

## Setting up amharriss@gmail.com as Admin

Your Supabase project appears to be inactive/paused. Here are the steps to set up admin access:

### Option 1: Via Supabase Dashboard (Recommended)

1. **Activate your Supabase project** (if paused)
   - Go to https://supabase.com/dashboard
   - Select your project
   - If paused, click "Resume Project"

2. **Create the user account:**
   - Go to Authentication → Users
   - Click "Add User"
   - Email: `amharriss@gmail.com`
   - Password: Choose a secure password
   - Auto Confirm User: YES
   - Click "Create User"

3. **Set admin privileges:**
   - Go to Table Editor → `members` table
   - Find the row with email `amharriss@gmail.com`
   - Set `is_admin` column to `true`
   - Click Save

### Option 2: Via SQL Editor

1. Resume your Supabase project
2. Go to SQL Editor
3. Run this query:

```sql
-- First create the auth user (if not exists)
-- Note: You'll need to do this via the Supabase Dashboard Authentication section

-- Then update the member record to be admin
UPDATE members 
SET is_admin = true 
WHERE email = 'amharriss@gmail.com';
```

### Option 3: Sign Up Then Promote

1. Go to your app at `/login`
2. Click "Sign Up" and create an account with `amharriss@gmail.com`
3. Complete the registration process
4. Then go to Supabase Dashboard → Table Editor → `members`
5. Find your account and set `is_admin = true`

### Verification

After setup, you can verify admin access by:
1. Logging in at `/login` with amharriss@gmail.com
2. You should see admin navigation options
3. Access `/admin` dashboard
4. Access `/admin/email-templates`

## Troubleshooting

- **Can't connect to Supabase**: Project may be paused - resume it in dashboard
- **User exists but not admin**: Update `is_admin` field in members table
- **Can't access admin pages**: Check that `is_admin = true` in database
