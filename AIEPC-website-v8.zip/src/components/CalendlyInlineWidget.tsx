import React, { useEffect } from 'react';

interface CalendlyInlineWidgetProps {
  url: string;
}

const CalendlyInlineWidget: React.FC<CalendlyInlineWidgetProps> = ({ url }) => {
  useEffect(() => {
    // Load Calendly script if not already loaded
    if (!document.querySelector('script[src="https://assets.calendly.com/assets/external/widget.js"]')) {
      const script = document.createElement('script');
      script.src = 'https://assets.calendly.com/assets/external/widget.js';
      script.async = true;
      document.body.appendChild(script);
    }

    // Initialize inline widget after script loads
    const timer = setTimeout(() => {
      if (window.Calendly && document.getElementById('calendly-inline-embed')) {
        window.Calendly.initInlineWidget({
          url: url,
          parentElement: document.getElementById('calendly-inline-embed'),
          prefill: {},
          utm: {}
        });
      }
    }, 100);

    return () => clearTimeout(timer);
  }, [url]);

  return (
    <div className="w-full mt-8">
      <div 
        id="calendly-inline-embed" 
        className="w-full rounded-lg bg-white shadow-lg"
        style={{ minWidth: '320px', height: '700px' }}
      />
    </div>
  );
};

// Extend Window interface for TypeScript
declare global {
  interface Window {
    Calendly: any;
  }
}

export default CalendlyInlineWidget;
