import { useRegistration } from '@/contexts/RegistrationContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';

export default function Step4IdentityProfession() {
  const { setStep, data, updateData } = useRegistration();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(5);
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-[#00308f] mb-2">Identity & Profession</h1>
      <p className="text-gray-600 mb-6">We collect the minimum necessary to verify eligibility and personalize benefits.</p>
      
      <form onSubmit={handleSubmit}>
        <Card>
          <CardContent className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Full Name *</label>
              <Input value={data.fullName} onChange={e => updateData({ fullName: e.target.value })} required />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Country *</label>
              <Select value={data.country} onValueChange={v => updateData({ country: v })} required>
                <SelectTrigger><SelectValue placeholder="Select country..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="United States">United States</SelectItem>
                  <SelectItem value="Canada">Canada</SelectItem>
                  <SelectItem value="United Kingdom">United Kingdom</SelectItem>
                  <SelectItem value="Australia">Australia</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">State/Province *</label>
              <Input value={data.state} onChange={e => updateData({ state: e.target.value })} required />
            </div>

            {data.country === 'United States' && (
              <div>
                <label className="block text-sm font-medium mb-2">ZIP Code *</label>
                <Input value={data.zipCode} onChange={e => updateData({ zipCode: e.target.value })} placeholder="12345" required />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium mb-2">Phone Number *</label>
              <Input type="tel" value={data.phoneNumber} onChange={e => updateData({ phoneNumber: e.target.value })} placeholder="+1 (555) 123-4567" required />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Primary Occupation *</label>
              <Input value={data.primaryOccupation} onChange={e => updateData({ primaryOccupation: e.target.value })} required />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Employer (optional)</label>
              <Input value={data.employer} onChange={e => updateData({ employer: e.target.value })} />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Employment Status *</label>
              <Select value={data.employmentStatus} onValueChange={v => updateData({ employmentStatus: v })}>
                <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="full-time">Full-time</SelectItem>
                  <SelectItem value="part-time">Part-time</SelectItem>
                  <SelectItem value="contractor">Contractor</SelectItem>
                  <SelectItem value="seeking">Seeking</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-4 mt-6">
              <Button type="button" variant="outline" onClick={() => setStep(3)}>← Back</Button>
              <Button type="submit" className="bg-[#00308f] hover:bg-[#5D8AA8]">Continue →</Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}

