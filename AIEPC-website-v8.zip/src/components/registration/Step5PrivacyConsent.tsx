import { useRegistration } from '@/contexts/RegistrationContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';

export default function Step5PrivacyConsent() {
  const { setStep, data, updateData } = useRegistration();

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-[#00308f] mb-2">Privacy & Consent</h1>
      <p className="text-gray-600 mb-6">Transparent controls that put you in charge of your data.</p>
      
      <Card className="mb-4">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-2">Privacy Pledge</h2>
          <p className="text-gray-700 text-sm mb-2">
            We never sell your data. You control what we collect, how we use it, and can revoke access anytime.
          </p>
          <a href="/privacy-policy" className="text-[#00308f] text-sm underline">Read full policy →</a>
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardContent className="p-6 space-y-4">
          <h2 className="text-xl font-semibold mb-4">Data Sharing Choices</h2>
          
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="font-medium">Personalize training & benefits</p>
              <p className="text-sm text-gray-600">Use my data to tailor resources to my role</p>
            </div>
            <Switch checked={data.consentPersonalize} onCheckedChange={v => updateData({ consentPersonalize: v })} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="font-medium">Share anonymized statistics</p>
              <p className="text-sm text-gray-600">Help improve advocacy with aggregated data</p>
            </div>
            <Switch checked={data.consentAnonymized} onCheckedChange={v => updateData({ consentAnonymized: v })} />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button variant="outline" onClick={() => setStep(4)}>← Back</Button>
        <Button onClick={() => setStep(6)} className="bg-[#00308f] hover:bg-[#5D8AA8]">Continue with these settings →</Button>
      </div>
    </div>
  );
}
