import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";

interface PaymentTrendsChartProps {
  payments: any[];
}

export default function PaymentTrendsChart({ payments }: PaymentTrendsChartProps) {
  // Group payments by month
  const paymentsByMonth = payments.reduce((acc: any, payment) => {
    const month = new Date(payment.date).toLocaleDateString("en-US", { month: "short", year: "2-digit" });
    if (!acc[month]) {
      acc[month] = 0;
    }
    acc[month] += payment.amount;
    return acc;
  }, {});

  const chartData = Object.entries(paymentsByMonth).map(([month, amount]) => ({
    month,
    amount,
  }));

  const chartConfig = {
    amount: {
      label: "Amount Paid",
      color: "#5D8AA8",
    },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment Trends</CardTitle>
      </CardHeader>
      <CardContent>
        {chartData.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No payment data available</p>
        ) : (
          <ChartContainer config={chartConfig} className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="amount" stroke="#5D8AA8" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  );
}
