import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, CreditCard } from "lucide-react";

interface UpcomingDuesSectionProps {
  nextPayment: any;
}

export default function UpcomingDuesSection({ nextPayment }: UpcomingDuesSectionProps) {
  if (!nextPayment) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Dues</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center py-8">No upcoming payments</p>
        </CardContent>
      </Card>
    );
  }

  const daysUntilDue = Math.ceil(
    (new Date(nextPayment.payment_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upcoming Dues</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center gap-3">
            <Calendar className="w-8 h-8 text-[#00308f]" />
            <div>
              <div className="font-semibold text-lg">${nextPayment.amount.toFixed(2)}</div>
              <div className="text-sm text-gray-600">
                Due {new Date(nextPayment.payment_date).toLocaleDateString()}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-[#00308f]">{daysUntilDue}</div>
            <div className="text-xs text-gray-600">days left</div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Billing Cycle:</span>
            <span className="font-semibold capitalize">{nextPayment.billing_cycle}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Status:</span>
            <span className="font-semibold capitalize">{nextPayment.status}</span>
          </div>
        </div>

        <Button className="w-full bg-[#00308f] hover:bg-[#5D8AA8]">
          <CreditCard className="w-4 h-4 mr-2" />
          Update Payment Method
        </Button>
      </CardContent>
    </Card>
  );
}
