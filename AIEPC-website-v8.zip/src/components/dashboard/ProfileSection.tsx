import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

interface ProfileSectionProps {
  member: any;
  onUpdate: () => void;
}

export default function ProfileSection({ member, onUpdate }: ProfileSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    first_name: member?.first_name || "",
    last_name: member?.last_name || "",
    phone: member?.phone || "",
    profession: member?.profession || "",
    identity: member?.identity || "",
  });
  const { toast } = useToast();

  const handleUpdate = async () => {
    try {
      const { error } = await supabase
        .from("members")
        .update(formData)
        .eq("id", member.id);

      if (error) throw error;

      toast({ title: "Profile updated successfully!" });
      setIsEditing(false);
      onUpdate();
    } catch (error: any) {
      toast({ title: "Error updating profile", description: error.message, variant: "destructive" });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Profile Information</span>
          <Button variant="outline" size="sm" onClick={() => setIsEditing(!isEditing)}>
            {isEditing ? "Cancel" : "Edit"}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isEditing ? (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>First Name</Label>
                <Input value={formData.first_name} onChange={(e) => setFormData({ ...formData, first_name: e.target.value })} />
              </div>
              <div>
                <Label>Last Name</Label>
                <Input value={formData.last_name} onChange={(e) => setFormData({ ...formData, last_name: e.target.value })} />
              </div>
            </div>
            <div>
              <Label>Phone</Label>
              <Input value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
            </div>
            <div>
              <Label>Profession</Label>
              <Input value={formData.profession} onChange={(e) => setFormData({ ...formData, profession: e.target.value })} />
            </div>
            <div>
              <Label>Identity</Label>
              <Input value={formData.identity} onChange={(e) => setFormData({ ...formData, identity: e.target.value })} />
            </div>
            <Button onClick={handleUpdate} className="w-full">Save Changes</Button>
          </>
        ) : (
          <>
            <div><strong>Name:</strong> {member?.first_name} {member?.last_name}</div>
            <div><strong>Email:</strong> {member?.email}</div>
            <div><strong>Phone:</strong> {member?.phone || "Not provided"}</div>
            <div><strong>Profession:</strong> {member?.profession || "Not provided"}</div>
            <div><strong>Identity:</strong> {member?.identity || "Not provided"}</div>
            <div><strong>Member Since:</strong> {new Date(member?.created_at).toLocaleDateString()}</div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
