import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

interface SubscriptionSettingsProps {
  currentBillingCycle: string;
  memberId: string;
  onUpdate: () => void;
}

export default function SubscriptionSettings({ currentBillingCycle, memberId, onUpdate }: SubscriptionSettingsProps) {
  const [billingCycle, setBillingCycle] = useState(currentBillingCycle);
  const { toast } = useToast();

  const handleUpdateBilling = async () => {
    try {
      const { error } = await supabase
        .from("dues_payments")
        .update({ billing_cycle: billingCycle })
        .eq("member_id", memberId)
        .eq("status", "pending");

      if (error) throw error;

      toast({ title: "Billing cycle updated successfully!" });
      onUpdate();
    } catch (error: any) {
      toast({ title: "Error updating billing cycle", description: error.message, variant: "destructive" });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Subscription Settings</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <Label>Billing Cycle</Label>
          <RadioGroup value={billingCycle} onValueChange={setBillingCycle}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="monthly" id="monthly" />
              <Label htmlFor="monthly">Monthly</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="annual" id="annual" />
              <Label htmlFor="annual">Annual (Save 15%)</Label>
            </div>
          </RadioGroup>
          {billingCycle !== currentBillingCycle && (
            <Button onClick={handleUpdateBilling} className="w-full">
              Update Billing Cycle
            </Button>
          )}
        </div>

        <div className="pt-4 border-t space-y-4">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                Cancel Membership
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will cancel your membership. You will lose access to all member benefits.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Keep Membership</AlertDialogCancel>
                <AlertDialogAction>Cancel Membership</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  );
}
