import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";

interface MembershipDurationChartProps {
  memberSince: string;
}

export default function MembershipDurationChart({ memberSince }: MembershipDurationChartProps) {
  const startDate = new Date(memberSince);
  const now = new Date();
  const monthsData = [];

  // Generate data for the last 6 months or membership duration (whichever is shorter)
  for (let i = 5; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    if (date >= startDate) {
      monthsData.push({
        month: date.toLocaleDateString("en-US", { month: "short" }),
        days: 30, // Active days in month
      });
    }
  }

  const chartConfig = {
    days: {
      label: "Active Days",
      color: "#00308f",
    },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Membership Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthsData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="days" fill="#00308f" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
