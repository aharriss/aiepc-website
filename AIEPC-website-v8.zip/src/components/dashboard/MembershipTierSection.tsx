import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2 } from "lucide-react";

interface MembershipTierSectionProps {
  tier: any;
  billingCycle: string;
}

export default function MembershipTierSection({ tier, billingCycle }: MembershipTierSectionProps) {
  if (!tier) return null;

  const price = billingCycle === "annual" ? tier.price_annual : tier.price_monthly;
  const benefits = tier.benefits ? JSON.parse(tier.benefits) : [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Membership Tier</span>
          <Badge className="bg-[#00308f]">{tier.name}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center py-4 bg-gray-50 rounded-lg">
          <div className="text-3xl font-bold text-[#00308f]">${price}</div>
          <div className="text-sm text-gray-600">per {billingCycle === "annual" ? "year" : "month"}</div>
        </div>
        
        <div>
          <h4 className="font-semibold mb-3">Benefits Included:</h4>
          <ul className="space-y-2">
            {benefits.map((benefit: string, index: number) => (
              <li key={index} className="flex items-start gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm">{benefit}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="pt-4 border-t">
          <p className="text-xs text-gray-600">
            Billing Cycle: <span className="font-semibold capitalize">{billingCycle}</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
