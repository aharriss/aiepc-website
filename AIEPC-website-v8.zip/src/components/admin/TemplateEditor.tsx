import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Upload } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TemplateEditorProps {
  template: any;
  onSave: (template: any) => void;
  onPreview: (template: any) => void;
}

export function TemplateEditor({ template, onSave, onPreview }: TemplateEditorProps) {
  const [subject, setSubject] = useState(template?.subject_line || '');
  const [body, setBody] = useState(template?.body_content || '');
  const [logoUrl, setLogoUrl] = useState(template?.logo_url || '');
  const [uploading, setUploading] = useState(false);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random()}.${fileExt}`;

    const { data, error } = await supabase.storage
      .from('email-logos')
      .upload(fileName, file);

    if (error) {
      console.error('Upload error:', error);
    } else {
      const { data: { publicUrl } } = supabase.storage
        .from('email-logos')
        .getPublicUrl(fileName);
      setLogoUrl(publicUrl);
    }
    setUploading(false);
  };

  const handleSave = () => {
    onSave({ ...template, subject_line: subject, body_content: body, logo_url: logoUrl });
  };

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div>
          <Label>Subject Line</Label>
          <Input value={subject} onChange={(e) => setSubject(e.target.value)} />
        </div>
        <div>
          <Label>Email Body (HTML supported, use {{variable}} for placeholders)</Label>
          <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={10} />
        </div>
        <div>
          <Label>Logo</Label>
          <div className="flex gap-2 items-center">
            <Input type="file" onChange={handleLogoUpload} accept="image/*" />
            {uploading && <span>Uploading...</span>}
          </div>
          {logoUrl && <img src={logoUrl} alt="Logo" className="mt-2 h-16" />}
        </div>
        <div className="flex gap-2">
          <Button onClick={handleSave}>Save Template</Button>
          <Button variant="outline" onClick={() => onPreview({ subject_line: subject, body_content: body, logo_url: logoUrl })}>
            Preview
          </Button>
        </div>
      </div>
    </Card>
  );
}
