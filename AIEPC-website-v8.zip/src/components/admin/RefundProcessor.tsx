import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { sendEmailNotification } from '@/lib/emailService';


interface Payment {
  id: string;
  transaction_id: string;
  amount: number;
  member_id: string;
  status: string;
}

interface RefundProcessorProps {
  payments: Payment[];
  onRefundProcessed: () => void;
}

export const RefundProcessor: React.FC<RefundProcessorProps> = ({ payments, onRefundProcessed }) => {
  const [selectedPayment, setSelectedPayment] = useState('');
  const [reason, setReason] = useState('');
  const [processing, setProcessing] = useState(false);
  const { toast } = useToast();

  const handleRefund = async () => {
    if (!selectedPayment || !reason) {
      toast({ title: "Error", description: "Please select a payment and provide a reason", variant: "destructive" });
      return;
    }

    setProcessing(true);
    try {
      // Get payment and member details
      const payment = payments.find(p => p.id === selectedPayment);
      if (!payment) throw new Error('Payment not found');

      const { data: memberData, error: memberError } = await supabase
        .from('members')
        .select('email, first_name, last_name')
        .eq('id', payment.member_id)
        .single();

      if (memberError) throw memberError;

      // Update payment status
      const { error } = await supabase
        .from('payment_history')
        .update({ status: 'refunded' })
        .eq('id', selectedPayment);

      if (error) throw error;

      // Send refund confirmation email
      await sendEmailNotification('refund_confirmation', memberData.email, {
        firstName: memberData.first_name,
        lastName: memberData.last_name,
        amount: payment.amount.toString(),
        originalPaymentDate: new Date(payment.created_at || Date.now()).toLocaleDateString(),
        refundDate: new Date().toLocaleDateString(),
        reason: reason,
      });

      toast({ title: "Success", description: "Refund processed and email sent" });
      setSelectedPayment('');
      setReason('');
      onRefundProcessed();
    } catch (error) {
      toast({ title: "Error", description: "Failed to process refund", variant: "destructive" });
    } finally {
      setProcessing(false);
    }
  };


  return (

    <Card>
      <CardHeader>
        <CardTitle>Process Refunds</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Select Payment</Label>
          <Select value={selectedPayment} onValueChange={setSelectedPayment}>
            <SelectTrigger>
              <SelectValue placeholder="Choose payment" />
            </SelectTrigger>
            <SelectContent>
              {payments.filter(p => p.status === 'completed').map((payment) => (
                <SelectItem key={payment.id} value={payment.id}>
                  {payment.transaction_id} - ${payment.amount}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Reason</Label>
          <Input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Enter refund reason"
          />
        </div>
        <Button onClick={handleRefund} disabled={processing} className="w-full">
          {processing ? 'Processing...' : 'Process Refund'}
        </Button>
      </CardContent>
    </Card>
  );
};
