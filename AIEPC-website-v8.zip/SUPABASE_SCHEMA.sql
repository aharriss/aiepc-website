-- AIEPC Complete Database Schema
-- Run this in Supabase SQL Editor

-- ============================================
-- TABLES
-- ============================================

-- Members table (synced with auth.users)
CREATE TABLE IF NOT EXISTS members (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  phone TEXT,
  profession TEXT,
  identity TEXT,
  membership_tier_id UUID REFERENCES membership_tiers(id),
  is_admin BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);


-- Membership tiers table
CREATE TABLE IF NOT EXISTS membership_tiers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL,
  price_monthly DECIMAL(10, 2) NOT NULL,
  price_annual DECIMAL(10, 2) NOT NULL,
  benefits JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Dues payments table
CREATE TABLE IF NOT EXISTS dues_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  payment_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  billing_cycle TEXT NOT NULL CHECK (billing_cycle IN ('monthly', 'annual')),
  status TEXT NOT NULL CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Payment history table
CREATE TABLE IF NOT EXISTS payment_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  transaction_id TEXT UNIQUE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status TEXT NOT NULL CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- INDEXES
-- ============================================

CREATE INDEX IF NOT EXISTS idx_members_email ON members(email);
CREATE INDEX IF NOT EXISTS idx_dues_payments_member_id ON dues_payments(member_id);
CREATE INDEX IF NOT EXISTS idx_dues_payments_status ON dues_payments(status);
CREATE INDEX IF NOT EXISTS idx_payment_history_member_id ON payment_history(member_id);
CREATE INDEX IF NOT EXISTS idx_payment_history_transaction_id ON payment_history(transaction_id);
CREATE INDEX IF NOT EXISTS idx_payment_history_date ON payment_history(date);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE membership_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE dues_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_history ENABLE ROW LEVEL SECURITY;

-- Members policies
CREATE POLICY "Members can view own data" ON members
  FOR SELECT USING (auth.uid()::text = id::text);

CREATE POLICY "Members can update own data" ON members
  FOR UPDATE USING (auth.uid()::text = id::text);

CREATE POLICY "Admins can view all members" ON members
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );

-- Allow users to insert their own member record during registration
CREATE POLICY "Users can insert own member record" ON members
  FOR INSERT WITH CHECK (auth.uid()::text = id::text);

CREATE POLICY "Admins can insert members" ON members
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );


CREATE POLICY "Admins can update all members" ON members
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );

-- Membership tiers policies
CREATE POLICY "Anyone can view tiers" ON membership_tiers
  FOR SELECT USING (true);

CREATE POLICY "Admins manage tiers" ON membership_tiers
  FOR ALL USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );

-- Dues payments policies
CREATE POLICY "Users can insert own dues" ON dues_payments
  FOR INSERT WITH CHECK (member_id::text = auth.uid()::text);

CREATE POLICY "Members view own dues" ON dues_payments
  FOR SELECT USING (member_id::text = auth.uid()::text);

CREATE POLICY "Admins view all dues" ON dues_payments
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );

CREATE POLICY "Admins manage dues" ON dues_payments
  FOR ALL USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );


-- Payment history policies
CREATE POLICY "Users can insert own payment history" ON payment_history
  FOR INSERT WITH CHECK (member_id::text = auth.uid()::text);

CREATE POLICY "Members view own history" ON payment_history
  FOR SELECT USING (member_id::text = auth.uid()::text);

CREATE POLICY "Members can update own dues" ON dues_payments
  FOR UPDATE USING (member_id::text = auth.uid()::text);

CREATE POLICY "Admins view all history" ON payment_history
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );

CREATE POLICY "Admins manage history" ON payment_history
  FOR ALL USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );


-- ============================================
-- SEED DATA (Optional)
-- ============================================

INSERT INTO membership_tiers (name, price_monthly, price_annual, benefits) VALUES
  ('Basic', 29.99, 299.99, '["Access to legal resources", "Monthly newsletter", "Member directory"]'),
  ('Professional', 49.99, 499.99, '["All Basic benefits", "Priority support", "Quarterly workshops", "Networking events"]'),
  ('Premium', 99.99, 999.99, '["All Professional benefits", "1-on-1 legal consultations", "Annual conference access", "Leadership opportunities"]')
ON CONFLICT (name) DO NOTHING;
