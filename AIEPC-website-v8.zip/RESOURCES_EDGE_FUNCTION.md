# Resources Partnership Inquiry Edge Function

## Overview
This edge function needs to be deployed to handle partnership inquiry form submissions from the Resources page.

## Function Name
`send-partnership-inquiry`

## Purpose
Sends partnership inquiry emails from service providers to adam@aiepc.org

## Deployment Instructions

Once the Supabase project is active/resumed, deploy this function using the Supabase CLI or dashboard:

```bash
supabase functions deploy send-partnership-inquiry
```

## Function Code

Save this as `supabase/functions/send-partnership-inquiry/index.ts`:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { name, email, company, message } = await req.json();

    const SENDGRID_API_KEY = Deno.env.get('SENDGRID_API_KEY');
    
    if (!SENDGRID_API_KEY) {
      throw new Error('SendGrid API key not configured');
    }

    const emailBody = {
      personalizations: [{
        to: [{ email: 'adam@aiepc.org' }],
        subject: 'New Partnership Inquiry - AIEPC Resources'
      }],
      from: { 
        email: 'noreply@aiepc.org',
        name: 'AIEPC Resources'
      },
      content: [{
        type: 'text/html',
        value: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #00308f;">New Partnership Inquiry</h2>
            <p>A service provider has expressed interest in partnering with AIEPC in the resources area.</p>
            
            <div style="background-color: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p><strong>Name:</strong> ${name}</p>
              <p><strong>Email:</strong> ${email}</p>
              <p><strong>Company:</strong> ${company || 'Not provided'}</p>
              <p><strong>Message:</strong></p>
              <p style="white-space: pre-wrap;">${message}</p>
            </div>
            
            <p style="color: #666; font-size: 12px; margin-top: 30px;">
              This email was sent from the AIEPC Resources partnership inquiry form.
            </p>
          </div>
        `
      }]
    };

    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SENDGRID_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailBody),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`SendGrid API error: ${errorText}`);
    }

    return new Response(
      JSON.stringify({ success: true, message: 'Partnership inquiry sent successfully' }),
      { headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  } catch (error) {
    console.error('Error sending partnership inquiry:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
});
```

## Required Environment Variables
- `SENDGRID_API_KEY` (already configured in Supabase)

## Testing
After deployment, test the function by:
1. Navigate to `/resources` on the website
2. Fill out the partnership inquiry form
3. Submit and verify email is received at adam@aiepc.org
