# Deployment Instructions for Resources Partnership Inquiry

## Current Status
The Supabase project is currently **INACTIVE**. The edge function code has been created but cannot be deployed until the project is resumed.

## Steps to Deploy When Project is Active

### 1. Resume Supabase Project
First, resume your Supabase project from the Supabase dashboard.

### 2. Deploy the Edge Function
Once the project is active, deploy the `send-partnership-inquiry` function:

```bash
supabase functions deploy send-partnership-inquiry
```

Or use the Supabase dashboard to deploy the function located at:
`supabase/functions/send-partnership-inquiry/index.ts`

### 3. Verify SendGrid Configuration
Ensure the `SENDGRID_API_KEY` environment variable is set in your Supabase project:
- Go to Project Settings > Edge Functions > Secrets
- Verify `SENDGRID_API_KEY` is present (already configured according to project info)

### 4. Test the Function
After deployment:
1. Navigate to `/resources` on your website
2. Fill out the partnership inquiry form
3. Submit and verify the email is received at adam@aiepc.org

## Function Details
- **Function Name**: `send-partnership-inquiry`
- **Purpose**: Sends partnership inquiry emails to adam@aiepc.org
- **API Used**: SendGrid API
- **Recipient**: adam@aiepc.org
- **Sender**: noreply@aiepc.org (AIEPC Resources)

## Troubleshooting
If emails are not being received:
1. Check Supabase function logs for errors
2. Verify SendGrid API key is valid
3. Ensure noreply@aiepc.org is verified in SendGrid
4. Check spam folder at adam@aiepc.org
