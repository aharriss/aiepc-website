# OAuth Provider Setup Guide

This guide explains how to configure Google, Microsoft (Azure), and Apple OAuth authentication in your Supabase project.

## Prerequisites
- Active Supabase project
- Access to Supabase Dashboard
- Developer accounts for each OAuth provider you want to enable

## Supabase Configuration

### 1. Get Your Redirect URLs
Your Supabase OAuth redirect URL format:
```
https://[YOUR-PROJECT-REF].supabase.co/auth/v1/callback
```

Find your project reference in: Supabase Dashboard → Settings → API

---

## Google OAuth Setup

### Step 1: Create Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable Google+ API

### Step 2: Configure OAuth Consent Screen
1. Navigate to: APIs & Services → OAuth consent screen
2. Choose "External" user type
3. Fill in required fields:
   - App name: "AIEPC"
   - User support email: your email
   - Developer contact: your email
4. Add scopes: `email`, `profile`, `openid`
5. Save and continue

### Step 3: Create OAuth Credentials
1. Go to: APIs & Services → Credentials
2. Click "Create Credentials" → "OAuth client ID"
3. Application type: "Web application"
4. Add Authorized redirect URIs:
   ```
   https://[YOUR-PROJECT-REF].supabase.co/auth/v1/callback
   ```
5. Copy Client ID and Client Secret

### Step 4: Configure in Supabase
1. Supabase Dashboard → Authentication → Providers
2. Enable Google provider
3. Paste Client ID and Client Secret
4. Save

---

## Microsoft (Azure AD) OAuth Setup

### Step 1: Register Application
1. Go to [Azure Portal](https://portal.azure.com/)
2. Navigate to: Azure Active Directory → App registrations
3. Click "New registration"
4. Name: "AIEPC"
5. Supported account types: "Accounts in any organizational directory and personal Microsoft accounts"
6. Redirect URI: Web → `https://[YOUR-PROJECT-REF].supabase.co/auth/v1/callback`
7. Register

### Step 2: Get Credentials
1. Copy "Application (client) ID"
2. Copy "Directory (tenant) ID"
3. Go to: Certificates & secrets → New client secret
4. Copy the secret value (shown once)

### Step 3: Configure API Permissions
1. Go to: API permissions → Add a permission
2. Microsoft Graph → Delegated permissions
3. Add: `email`, `openid`, `profile`
4. Grant admin consent

### Step 4: Configure in Supabase
1. Supabase Dashboard → Authentication → Providers
2. Enable Azure provider
3. Paste Client ID and Client Secret
4. Azure Tenant URL: `https://login.microsoftonline.com/common`
5. Save

---

## Apple OAuth Setup

### Step 1: Create App ID
1. Go to [Apple Developer](https://developer.apple.com/)
2. Certificates, Identifiers & Profiles → Identifiers
3. Click "+" → App IDs → Continue
4. Description: "AIEPC"
5. Bundle ID: `com.aiepc.app` (or your domain)
6. Enable "Sign in with Apple"
7. Save

### Step 2: Create Services ID
1. Identifiers → "+" → Services IDs
2. Description: "AIEPC Web"
3. Identifier: `com.aiepc.web`
4. Enable "Sign in with Apple"
5. Configure:
   - Primary App ID: Select your App ID
   - Domains: Your domain
   - Return URLs: `https://[YOUR-PROJECT-REF].supabase.co/auth/v1/callback`
6. Save

### Step 3: Create Private Key
1. Keys → "+" → Register a new key
2. Key Name: "AIEPC Sign in with Apple Key"
3. Enable "Sign in with Apple"
4. Configure → Select your App ID
5. Save and download the .p8 file (keep secure!)
6. Note the Key ID

### Step 4: Configure in Supabase
1. Supabase Dashboard → Authentication → Providers
2. Enable Apple provider
3. Services ID: Your Services ID
4. Team ID: From Apple Developer Account
5. Key ID: From the key you created
6. Private Key: Paste contents of .p8 file
7. Save

---

## Testing OAuth Flow

1. Navigate to login page: `/login`
2. Click on OAuth provider button
3. Complete authentication with provider
4. Should redirect to `/dashboard` on success

## Troubleshooting

### Common Issues:
- **Redirect URI mismatch**: Ensure URIs match exactly in provider and Supabase
- **Missing scopes**: Verify email/profile scopes are enabled
- **Apple key errors**: Ensure .p8 file contents are pasted correctly
- **Azure tenant**: Use `/common` for multi-tenant support

### Verify Configuration:
1. Check Supabase logs: Dashboard → Logs → Auth
2. Browser console for client-side errors
3. Test each provider individually

---

## Security Notes

- Keep OAuth credentials secure
- Never commit client secrets to version control
- Rotate secrets periodically
- Use environment-specific credentials for dev/prod
- Monitor OAuth usage in provider dashboards

---

## Support

For issues:
- Supabase Auth Docs: https://supabase.com/docs/guides/auth
- Google OAuth: https://developers.google.com/identity/protocols/oauth2
- Microsoft Identity: https://docs.microsoft.com/en-us/azure/active-directory/
- Apple Sign In: https://developer.apple.com/sign-in-with-apple/
