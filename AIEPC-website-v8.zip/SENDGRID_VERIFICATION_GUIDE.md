# SendGrid Email System Verification Guide

## Why You Didn't Receive the Email

The most common reason is that **the sender email address needs to be verified in SendGrid**.

## Step-by-Step Verification Process

### 1. Verify Sender Email in SendGrid

1. Log in to your SendGrid account at https://app.sendgrid.com
2. Go to **Settings** → **Sender Authentication**
3. Click on **Single Sender Verification**
4. Add and verify the email: **noreply@aiepc.org** (or whatever domain you own)
5. SendGrid will send a verification email to that address
6. Click the verification link in that email

**Important:** You can only send emails FROM addresses you've verified in SendGrid.

### 2. Check Your SendGrid API Key Permissions

1. Go to **Settings** → **API Keys**
2. Find your API key (or create a new one)
3. Ensure it has **Full Access** or at least **Mail Send** permissions
4. Copy the API key

### 3. Verify the API Key is Set in Supabase

The SENDGRID_API_KEY secret is already configured in your Supabase project.

### 4. Test the Email Function Directly

You can test the edge function using curl or Postman:

```bash
curl -X POST https://hhqhvusswlvwgmjdnxal.supabase.co/functions/v1/send-welcome-email \
  -H "Content-Type: application/json" \
  -d '{
    "email": "your-test-email@example.com",
    "firstName": "Test",
    "lastName": "User",
    "duesType": "monthly",
    "membershipTier": "Active Member"
  }'
```

### 5. Check SendGrid Activity

1. In SendGrid, go to **Activity**
2. Look for recent email attempts
3. Check if emails are being blocked, bounced, or delivered
4. Look for error messages

## Common Issues & Solutions

### Issue: "403 Forbidden" from SendGrid
**Solution:** Your API key doesn't have the right permissions. Create a new API key with Full Access.

### Issue: "Sender email not verified"
**Solution:** Complete Step 1 above to verify your sender email.

### Issue: Email goes to spam
**Solution:** 
- Set up domain authentication in SendGrid (Settings → Sender Authentication → Domain Authentication)
- This adds SPF and DKIM records to your domain

### Issue: Function not found
**Solution:** The edge function file exists but may need to be deployed. Check Supabase dashboard → Edge Functions.

## Alternative: Use a Verified Email

If you don't own aiepc.org, you can:

1. Use a Gmail address you control (e.g., your-email@gmail.com)
2. Verify that email in SendGrid
3. Update the edge function to use that email as the sender

To update the sender email, modify line 42 in `supabase/functions/send-welcome-email/index.ts`:

```typescript
from: {
  email: "your-verified-email@gmail.com",  // Change this
  name: "AIEPC Membership Team"
}
```

## Testing Checklist

- [ ] Sender email verified in SendGrid
- [ ] API key has Mail Send permissions
- [ ] API key is set in Supabase secrets
- [ ] Test email sent successfully via curl
- [ ] Check SendGrid Activity for delivery status
- [ ] Register in the app and check for email
- [ ] Check spam folder if not in inbox

## Node.js Note

SendGrid's REST API works with any language (Deno, Node.js, Python, etc.). The edge function uses the REST API directly, so it doesn't matter that you told SendGrid you'd use Node.js. The API is the same regardless of the language.
