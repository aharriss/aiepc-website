# Stripe Payment Integration Setup

## Overview
The checkout page now uses Stripe Elements for secure payment processing.

## Configuration Required

### 1. Environment Variables
Add to your `.env` file:
```
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
```

### 2. Supabase Edge Function
The edge function `create-payment-intent` is ready in `supabase/functions/create-payment-intent/index.ts`

Deploy it with:
```bash
supabase functions deploy create-payment-intent
```

The function uses the `STRIPE_SECRET_KEY` environment variable (already configured in Supabase).

## How It Works

1. **CheckoutPage** displays order summary and payment form
2. **StripePaymentForm** component:
   - Calls edge function to create payment intent
   - Loads Stripe Elements with client secret
   - Handles card input securely
   - Processes payment and redirects on success

## Testing

Use Stripe test cards:
- Success: 4242 4242 4242 4242
- Decline: 4000 0000 0000 0002

Any future expiry date and any 3-digit CVC.

## Dependencies Added
- @stripe/stripe-js
- @stripe/react-stripe-js
