# Email Verification Reminder System Setup

This guide explains how to set up automated email reminders for users who haven't verified their email addresses.

## Overview

The system sends automatic reminder emails to unverified users:
- **24 hours** after registration
- **72 hours** after registration

## Step 1: Create Database Table

Run this SQL in your Supabase SQL Editor:

```sql
-- Create table to track verification reminder emails
CREATE TABLE IF NOT EXISTS verification_reminders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  email TEXT NOT NULL,
  reminder_type TEXT NOT NULL CHECK (reminder_type IN ('24_hour', '72_hour')),
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_verification_reminders_user_id 
  ON verification_reminders(user_id);
CREATE INDEX IF NOT EXISTS idx_verification_reminders_type 
  ON verification_reminders(user_id, reminder_type);

-- Enable RLS
ALTER TABLE verification_reminders ENABLE ROW LEVEL SECURITY;

-- Admins can view reminders
CREATE POLICY "Admins can view all reminders" ON verification_reminders
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM members WHERE id::text = auth.uid()::text AND is_admin = true)
  );
```

## Step 2: Deploy Edge Function

The edge function code is in `supabase/functions/send-verification-reminders/index.ts`.

Deploy it using:
```bash
supabase functions deploy send-verification-reminders
```

## Step 3: Set Up Cron Job

In Supabase Dashboard:
1. Go to Database → Cron Jobs (pg_cron extension)
2. Enable the pg_cron extension if not already enabled
3. Create a new cron job:

```sql
-- Run every hour to check for users needing reminders
SELECT cron.schedule(
  'send-verification-reminders',
  '0 * * * *', -- Every hour
  $$
  SELECT net.http_post(
    url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/send-verification-reminders',
    headers := '{"Authorization": "Bearer YOUR_ANON_KEY"}'::jsonb
  );
  $$
);
```

Replace:
- `YOUR_PROJECT_REF` with your Supabase project reference
- `YOUR_ANON_KEY` with your Supabase anon key

## Step 4: Test the Function

You can manually trigger the function to test:

```bash
curl -X POST \
  https://YOUR_PROJECT_REF.supabase.co/functions/v1/send-verification-reminders \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

## How It Works

1. The edge function runs every hour (via cron job)
2. It queries `auth.users` for unverified users
3. For each unverified user, it checks if they were created ~24h or ~72h ago
4. If a reminder is due and hasn't been sent, it sends an email via SendGrid
5. It logs the sent reminder to prevent duplicates

## Monitoring

Check reminder logs:
```sql
SELECT * FROM verification_reminders ORDER BY sent_at DESC;
```

View unverified users:
```sql
SELECT id, email, created_at, email_confirmed_at 
FROM auth.users 
WHERE email_confirmed_at IS NULL;
```
